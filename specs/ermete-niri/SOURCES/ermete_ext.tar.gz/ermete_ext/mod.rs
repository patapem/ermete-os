pub mod floating_manager;

/// Inizializza l'Ermete Engine all'avvio di Niri
pub fn init_floating_engine() {
    println!("🦅 Ermete OS: Inizializzazione Floating-First UX Engine...");
    floating_manager::setup_hooks();
}
